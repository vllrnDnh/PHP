<div class="section career-objective">
    <h2>Career Objective</h2>
    <p>Hi, I'm Dinah Chrishalei R. Villarina and I'm an aspiring Software Engineer with a passion for designing, developing, and innovating computer programs that solve real-world problems. I strive to contribute to a society where technology uplifts communities, supports education, and drives meaningful growth. Eager to learn, collaborate, and build inclusive digital solutions.</p>
</div>
