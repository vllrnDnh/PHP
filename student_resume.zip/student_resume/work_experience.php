<div class="section work-experience">
    <h2>Work Experience</h2>
    <p>Currently building academic and volunteer design portfolio. Open to internship opportunities in digital design, branding, and creative content creation.</p>
</div>
