<div class="section education">
    <h2>Education</h2>
    <p><strong>2022 – present</strong><br>
    Digital Art & Design at <span class="highlight">FPT University</span></p>
</div>
