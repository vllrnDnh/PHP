<div class="section affiliation">
    <h2>Activities / Affiliations</h2>
    <ul>
        <li><strong>2024–present:</strong> Member of FPT University Voluntary Student Community</li>
        <li><strong>2020–2021:</strong> Head of Design, Nguyen Dinh Chieu Volunteer Club</li>
        <li><strong>2019–2020:</strong> Member, Nguyen Dinh Chieu English Club</li>
    </ul>
</div>
