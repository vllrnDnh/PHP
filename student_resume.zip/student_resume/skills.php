<div class="section skills">
    <h2>Software Skills</h2>
    <ul class="skills-list">
        <li>Adobe Illustrator</li>
        <li>Photoshop</li>
        <li>After Effects</li>
        <li>InDesign</li>
        <li>Dreamweaver</li>
    </ul>
    <h3>Certificates</h3>
    <ul>
        <li>UI / UX Design – California Institute of the Arts</li>
        <li>Academic Skills for University Success – University of Sydney</li>
        <li>IELTS 6.5 – IDP Education</li>
    </ul>
</div>
