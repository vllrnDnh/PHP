<div class="section personal-info">
    <img src="profile.jpg" alt="Profile Picture" class="profile-pic">
    <div>
        <h1>Dinah Villarina</h1>
        <p>Computer Science Student</p>
        <p><strong>Fullname:</strong> Dinah Chrishalei R. Villarina</p>
        <p><strong>Date of Birth:</strong> 08/02/2003</p>
        <p><strong>Address:</strong> Imus, Cavite</p>
        <p><strong>Languages:</strong> Filipino (Native), English (Proficient)</p>
    </div>
</div>
